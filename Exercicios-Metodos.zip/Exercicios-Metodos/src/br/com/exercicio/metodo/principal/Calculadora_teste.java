package br.com.exercicio.metodo.principal;

import java.util.Scanner;

import br.com.exercicio.metodo.beans.Calculadora;

public class Calculadora_teste {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scn = new Scanner(System.in);
		String calculo = "";
		Calculadora c = new Calculadora();
	
			
		
		System.out.println("Escolha o sinal +,-,* e / ");
		calculo = scn.next();
		switch (calculo) {
		case "+":
			System.out.println("Informe dois n�meros");
			c.setSoma2(scn.nextInt(), scn.nextInt());
			break;
		case "-":
			System.out.println("Informe dois n�meros");
			c.setSub(scn.nextDouble(), scn.nextDouble());
			break;
		case "*":
			System.out.println("Informe dois n�meros");
			c.setMult(scn.nextDouble(), scn.nextDouble());
			break;
		case "/":
			System.out.println("Informe dois n�meros");
			c.setDiv(scn.nextDouble(), scn.nextDouble());
			break;
		
		default:
			break;
		}
	
		// System.out.println(c.getSoma(2, 3));

	}

}
