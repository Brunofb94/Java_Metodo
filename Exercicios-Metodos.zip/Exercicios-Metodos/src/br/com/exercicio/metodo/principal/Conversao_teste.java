package br.com.exercicio.metodo.principal;

import java.util.Scanner;

import br.com.exercicio.metodo.beans.ConvertHoras;

public class Conversao_teste {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scn = new Scanner(System.in);
		ConvertHoras c  =  new ConvertHoras();
		System.out.println("Informe os segundos ");
		c.setConverter(scn.nextFloat());
		
	}

}
