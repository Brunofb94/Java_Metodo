package br.com.exercicio.metodo.principal;

import java.util.Scanner;

import br.com.exercicio.metodo.beans.Exercicio4;

public class Exercicio4_teste {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scn = new Scanner(System.in);
		Exercicio4 e = new Exercicio4();
		e.Calculo_Media("a",scn.nextDouble(), scn.nextDouble(), scn.nextDouble());
		e.Cal("p", 7, 6,8 , 7.5);
		scn.close();

	}

}
