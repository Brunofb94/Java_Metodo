package br.com.exercicio.metodo.principal;

import java.util.Scanner;

import br.com.exercicio.metodo.beans.Exercicio3;

public class Exercicio3_teste {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scn = new Scanner(System.in);
		Exercicio3 e = new Exercicio3();
		
		e.Percentual(scn.nextDouble(), scn.nextDouble());

	}

}
