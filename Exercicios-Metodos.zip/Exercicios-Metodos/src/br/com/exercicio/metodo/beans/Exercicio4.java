package br.com.exercicio.metodo.beans;

import java.text.DecimalFormat;

public class Exercicio4 {
	// private double[] nota = new double[3];
	private String letra;
	private double nota1, nota2, nota3;

	public void Calculo_Media( String letra,double nota1, double nota2, double nota3) {
		// double[] nota1 = new double[3];
		double notas = 0.0;
		double resultado;
		DecimalFormat fmt = new DecimalFormat("0.00");
		if (letra == "a") {
			notas = nota1 + nota2 + nota3;
			resultado = notas / 3;
			String formatar = fmt.format(resultado);
			
			System.out.println("A m�dia aritm�tica �:   " +  formatar);
			/*
			 * for (int i = 0; i < this.nota.length; i++) { notas += nota1[i]; }
			 */
		}

	}
	
	public void Cal( String word, double n1, double n2, double n3, double n4) {
		double notas = 0.0;
		double resultado;
		DecimalFormat fmt = new DecimalFormat("0.0");
		if (word == "p") {
			notas = (n1 * 1) +( n2 * 2) + (n3 * 3) + (n4 * 4);
			
			resultado = notas / 10;
			String formatar = fmt.format(resultado);
			System.out.println("A m�dia aritm�tica �:   " +  formatar);


		}
	}
	

}
