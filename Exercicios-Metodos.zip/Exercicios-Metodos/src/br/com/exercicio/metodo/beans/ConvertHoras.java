package br.com.exercicio.metodo.beans;

import java.text.DecimalFormat;

public class ConvertHoras {
	private float segundos;
	
	public void setConverter(float horas) {
		
		DecimalFormat fmt = new DecimalFormat("0.00");
		
		segundos  = horas / 3600;
		String string = fmt.format(segundos);
		System.out.println("A convers�o para horas � "  + string + " HRS ");
		
	}

}
