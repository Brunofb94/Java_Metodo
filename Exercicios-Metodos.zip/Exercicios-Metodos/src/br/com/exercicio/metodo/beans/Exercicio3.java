package br.com.exercicio.metodo.beans;

import java.text.DecimalFormat;

public class Exercicio3 {
	private double produto_antigo;
	private double produto_atual;
	
	public void Percentual (double produto_antigo, double produto_atual) {
		DecimalFormat fmt = new DecimalFormat("0.00");
		double percentual_acrescimo;
		double conta;
		
		conta = produto_antigo - produto_atual;
		percentual_acrescimo = conta / 100;
		String conversao = fmt.format(percentual_acrescimo);
		System.out.println("O percentual de acr�scimo �:  " + conversao);
	}

}
