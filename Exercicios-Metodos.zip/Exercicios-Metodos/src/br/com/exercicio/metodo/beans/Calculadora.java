package br.com.exercicio.metodo.beans;

public class Calculadora {
	private int soma;
	private double divisao;
	private double multiplicacao;
	private double subtracao;

	public int getSoma() {
		return soma;
	}

	public void setSoma(int soma) {
		this.soma = soma;
	}

	public double getDivisao() {
		return divisao;
	}

	public void setDivisao(double divisao) {
		this.divisao = divisao;
	}

	public double getMultiplicacao() {
		return multiplicacao;
	}

	public void setMultiplicacao(double multiplicacao) {
		this.multiplicacao = multiplicacao;
	}

	public double getSubtracao() {
		return subtracao;
	}

	public void setSubtracao(double subtracao) {
		this.subtracao = subtracao;
	}

	public void setSoma2(int n1, int n2) {
		soma = n1 + n2;
		System.out.println("Resultado " + soma);
	}

	public void setSub(double n1, double n2) {
		subtracao = n1 - n2;
		System.out.println("Resultado: " + subtracao);
	}

	public void setDiv(double n1, double n2) {
		if (n1 == 0 || n2 == 0) {
			System.out.println("N�o � possivel fazer a divis�o");
		} else {
			divisao = n1 / n2;
			System.out.println("Resultado: " + divisao);
			
		}
	}

	public void setMult(double n1, double n2) {
		multiplicacao = n1 * n2;
		System.out.println("Resultado: " + multiplicacao);
	}

}
